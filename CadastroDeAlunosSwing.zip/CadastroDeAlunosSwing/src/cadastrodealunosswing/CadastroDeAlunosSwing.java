package cadastrodealunosswing;

public class CadastroDeAlunosSwing {

    public static void main(String[] args) {
        TelaPrincipal tela = new TelaPrincipal();
        tela.setVisible(true);
    }
    
}
